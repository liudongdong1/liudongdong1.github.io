# ucrdtw_storm

A Storm implementation of a time series subsequence search algorithm which was introduced in: http://www.cs.ucr.edu/~eamonn/SIGKDD_trillion.pdf

Reference paper:
Rakthanmanon T, Campana B, Mueen A, Batista G, Westover B, Zhu Q, Zakaria J, Keogh E (2012) Searching and mining trillions of time series subsequences under dynamic time warping. Paper presented at the Proceedings of the 18th ACM SIGKDD international conference on Knowledge discovery and data mining, Beijing, China.
