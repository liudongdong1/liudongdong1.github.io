# Test data

Found in the original sources. Use with
```
../build/bin/ucr_ed_orig data.txt query.txt 128
../build/bin/ucr_dtw_orig data.txt query.txt 128 0.05
```
