# ucr-suite-cpp
Updating the UCR Suite to use modern C++. Original code an authors: http://www.cs.ucr.edu/~eamonn/UCRsuite.html
