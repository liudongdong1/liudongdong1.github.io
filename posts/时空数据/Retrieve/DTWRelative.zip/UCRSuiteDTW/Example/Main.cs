﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UCRCSharp
{
    class MainT
    {
        public static void Main(string[] args)
        {
            TempUCR.DTW("F:\\DTW\\trillion\\Executable\\Data.txt", "F:\\DTW\\trillion\\Executable\\Query.txt", 128, 0.05);
           
            Console.ReadKey();
        }
    }
}
