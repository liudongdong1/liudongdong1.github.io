UCRSuiteDTW
===========

C# implementation of multi-dimensional Dynamic Time Warping using UCR Suite optimizations

See UCR Suite DTW paper "Searching and Mining Trillions of Time Series Subsequences under Dynamic Time Warping":
http://www.cs.ucr.edu/~eamonn/SIGKDD_trillion.pdf

Original C# code (greatly modified in this repository) found here: http://debugitalready.blogspot.com/2012/12/dynamic-time-warping-ucr-suite-in-c.html

