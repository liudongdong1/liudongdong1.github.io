﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
namespace UCRCSharp
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            new TempUCR().lower_upper_lemire()
        }
    }
}
